criaCartao(
    'Tyler, the creator',
    'Qual seu ultimo album de estudio?',
    'CHROMAKOPIA'
)

criaCartao(
    'Beabadoobee',
    'Qual a música mais famosa do seu ultimo album de estudio?',
    'Take a bite'
)

criaCartao(
    'Clairo',
    'O que acontece no clipe de juna?',
    'Uma luta uau!!!'
)

criaCartao(
    'Joji',
    'Em smithereens qual a musica que ele diz que morreria por alguem',
    'Die for you'
)